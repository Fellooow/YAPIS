# Generated from C:/Users/Asus/PycharmProjects/antlrTest\gramma.g4 by ANTLR 4.12.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,42,276,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,1,0,5,0,38,8,0,10,0,12,0,
        41,9,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,66,8,1,1,2,1,2,1,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,86,8,2,1,
        3,1,3,1,3,1,3,1,4,1,4,1,4,5,4,95,8,4,10,4,12,4,98,9,4,1,4,1,4,1,
        4,1,4,5,4,104,8,4,10,4,12,4,107,9,4,1,5,1,5,1,5,1,5,1,5,1,6,1,6,
        1,6,1,6,1,6,1,6,1,7,1,7,1,7,1,7,1,7,1,7,5,7,126,8,7,10,7,12,7,129,
        9,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,138,8,7,1,8,5,8,141,8,8,10,8,
        12,8,144,9,8,1,9,1,9,1,9,1,9,1,9,1,9,5,9,152,8,9,10,9,12,9,155,9,
        9,1,9,1,9,1,10,1,10,1,10,1,10,1,10,1,10,1,10,5,10,166,8,10,10,10,
        12,10,169,9,10,1,10,1,10,1,11,1,11,1,11,1,11,1,11,5,11,178,8,11,
        10,11,12,11,181,9,11,1,11,1,11,1,11,1,11,1,12,1,12,1,12,1,12,1,12,
        1,12,1,12,5,12,194,8,12,10,12,12,12,197,9,12,3,12,199,8,12,1,12,
        1,12,1,12,5,12,204,8,12,10,12,12,12,207,9,12,1,12,1,12,1,13,1,13,
        1,13,1,13,1,13,1,13,1,13,5,13,218,8,13,10,13,12,13,221,9,13,1,13,
        1,13,1,14,1,14,1,14,1,15,1,15,1,15,1,15,1,15,1,15,1,16,1,16,1,17,
        1,17,1,17,1,17,1,17,1,17,3,17,242,8,17,1,17,1,17,1,17,1,17,1,17,
        1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,
        1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,5,17,271,8,17,10,17,
        12,17,274,9,17,1,17,0,1,34,18,0,2,4,6,8,10,12,14,16,18,20,22,24,
        26,28,30,32,34,0,1,1,0,38,41,297,0,39,1,0,0,0,2,65,1,0,0,0,4,85,
        1,0,0,0,6,87,1,0,0,0,8,91,1,0,0,0,10,108,1,0,0,0,12,113,1,0,0,0,
        14,119,1,0,0,0,16,142,1,0,0,0,18,145,1,0,0,0,20,158,1,0,0,0,22,172,
        1,0,0,0,24,186,1,0,0,0,26,210,1,0,0,0,28,224,1,0,0,0,30,227,1,0,
        0,0,32,233,1,0,0,0,34,241,1,0,0,0,36,38,3,2,1,0,37,36,1,0,0,0,38,
        41,1,0,0,0,39,37,1,0,0,0,39,40,1,0,0,0,40,42,1,0,0,0,41,39,1,0,0,
        0,42,43,5,0,0,1,43,1,1,0,0,0,44,45,5,36,0,0,45,66,3,6,3,0,46,47,
        5,36,0,0,47,66,3,8,4,0,48,49,5,36,0,0,49,66,3,14,7,0,50,51,5,36,
        0,0,51,66,3,18,9,0,52,53,5,36,0,0,53,66,3,34,17,0,54,55,5,36,0,0,
        55,66,3,10,5,0,56,57,5,36,0,0,57,66,3,12,6,0,58,66,3,20,10,0,59,
        60,5,36,0,0,60,66,3,24,12,0,61,62,5,36,0,0,62,66,3,26,13,0,63,64,
        5,36,0,0,64,66,3,28,14,0,65,44,1,0,0,0,65,46,1,0,0,0,65,48,1,0,0,
        0,65,50,1,0,0,0,65,52,1,0,0,0,65,54,1,0,0,0,65,56,1,0,0,0,65,58,
        1,0,0,0,65,59,1,0,0,0,65,61,1,0,0,0,65,63,1,0,0,0,66,3,1,0,0,0,67,
        68,3,34,17,0,68,69,5,6,0,0,69,70,3,34,17,0,70,86,1,0,0,0,71,72,3,
        34,17,0,72,73,5,7,0,0,73,74,3,34,17,0,74,86,1,0,0,0,75,76,3,34,17,
        0,76,77,5,9,0,0,77,78,3,34,17,0,78,86,1,0,0,0,79,80,5,41,0,0,80,
        81,5,9,0,0,81,86,5,33,0,0,82,83,5,41,0,0,83,84,5,9,0,0,84,86,5,34,
        0,0,85,67,1,0,0,0,85,71,1,0,0,0,85,75,1,0,0,0,85,79,1,0,0,0,85,82,
        1,0,0,0,86,5,1,0,0,0,87,88,5,41,0,0,88,89,5,1,0,0,89,90,3,34,17,
        0,90,7,1,0,0,0,91,96,5,41,0,0,92,93,5,19,0,0,93,95,5,41,0,0,94,92,
        1,0,0,0,95,98,1,0,0,0,96,94,1,0,0,0,96,97,1,0,0,0,97,99,1,0,0,0,
        98,96,1,0,0,0,99,100,5,1,0,0,100,105,3,34,17,0,101,102,5,19,0,0,
        102,104,3,34,17,0,103,101,1,0,0,0,104,107,1,0,0,0,105,103,1,0,0,
        0,105,106,1,0,0,0,106,9,1,0,0,0,107,105,1,0,0,0,108,109,5,30,0,0,
        109,110,5,12,0,0,110,111,5,41,0,0,111,112,5,13,0,0,112,11,1,0,0,
        0,113,114,5,41,0,0,114,115,5,1,0,0,115,116,5,31,0,0,116,117,5,12,
        0,0,117,118,5,13,0,0,118,13,1,0,0,0,119,120,5,22,0,0,120,121,5,12,
        0,0,121,122,3,4,2,0,122,123,5,13,0,0,123,127,5,14,0,0,124,126,3,
        2,1,0,125,124,1,0,0,0,126,129,1,0,0,0,127,125,1,0,0,0,127,128,1,
        0,0,0,128,130,1,0,0,0,129,127,1,0,0,0,130,137,5,15,0,0,131,132,5,
        36,0,0,132,133,5,29,0,0,133,134,5,14,0,0,134,135,3,16,8,0,135,136,
        5,15,0,0,136,138,1,0,0,0,137,131,1,0,0,0,137,138,1,0,0,0,138,15,
        1,0,0,0,139,141,3,2,1,0,140,139,1,0,0,0,141,144,1,0,0,0,142,140,
        1,0,0,0,142,143,1,0,0,0,143,17,1,0,0,0,144,142,1,0,0,0,145,146,5,
        23,0,0,146,147,5,12,0,0,147,148,3,4,2,0,148,149,5,13,0,0,149,153,
        5,14,0,0,150,152,3,2,1,0,151,150,1,0,0,0,152,155,1,0,0,0,153,151,
        1,0,0,0,153,154,1,0,0,0,154,156,1,0,0,0,155,153,1,0,0,0,156,157,
        5,15,0,0,157,19,1,0,0,0,158,159,5,36,0,0,159,160,5,25,0,0,160,161,
        5,12,0,0,161,162,5,41,0,0,162,163,5,13,0,0,163,167,5,14,0,0,164,
        166,3,22,11,0,165,164,1,0,0,0,166,169,1,0,0,0,167,165,1,0,0,0,167,
        168,1,0,0,0,168,170,1,0,0,0,169,167,1,0,0,0,170,171,5,15,0,0,171,
        21,1,0,0,0,172,173,5,36,0,0,173,174,5,24,0,0,174,175,5,38,0,0,175,
        179,5,14,0,0,176,178,3,2,1,0,177,176,1,0,0,0,178,181,1,0,0,0,179,
        177,1,0,0,0,179,180,1,0,0,0,180,182,1,0,0,0,181,179,1,0,0,0,182,
        183,5,36,0,0,183,184,5,32,0,0,184,185,5,15,0,0,185,23,1,0,0,0,186,
        187,5,26,0,0,187,188,5,41,0,0,188,198,5,12,0,0,189,199,5,42,0,0,
        190,195,3,32,16,0,191,192,5,19,0,0,192,194,3,32,16,0,193,191,1,0,
        0,0,194,197,1,0,0,0,195,193,1,0,0,0,195,196,1,0,0,0,196,199,1,0,
        0,0,197,195,1,0,0,0,198,189,1,0,0,0,198,190,1,0,0,0,199,200,1,0,
        0,0,200,201,5,13,0,0,201,205,5,14,0,0,202,204,3,2,1,0,203,202,1,
        0,0,0,204,207,1,0,0,0,205,203,1,0,0,0,205,206,1,0,0,0,206,208,1,
        0,0,0,207,205,1,0,0,0,208,209,5,15,0,0,209,25,1,0,0,0,210,211,5,
        41,0,0,211,212,5,1,0,0,212,213,5,41,0,0,213,214,5,12,0,0,214,219,
        3,32,16,0,215,216,5,19,0,0,216,218,3,32,16,0,217,215,1,0,0,0,218,
        221,1,0,0,0,219,217,1,0,0,0,219,220,1,0,0,0,220,222,1,0,0,0,221,
        219,1,0,0,0,222,223,5,13,0,0,223,27,1,0,0,0,224,225,5,27,0,0,225,
        226,3,34,17,0,226,29,1,0,0,0,227,228,5,16,0,0,228,229,5,38,0,0,229,
        230,5,19,0,0,230,231,5,38,0,0,231,232,5,17,0,0,232,31,1,0,0,0,233,
        234,7,0,0,0,234,33,1,0,0,0,235,236,6,17,-1,0,236,242,5,41,0,0,237,
        242,5,38,0,0,238,242,5,40,0,0,239,242,5,39,0,0,240,242,3,30,15,0,
        241,235,1,0,0,0,241,237,1,0,0,0,241,238,1,0,0,0,241,239,1,0,0,0,
        241,240,1,0,0,0,242,272,1,0,0,0,243,244,10,9,0,0,244,245,5,2,0,0,
        245,271,3,34,17,10,246,247,10,8,0,0,247,248,5,4,0,0,248,271,3,34,
        17,9,249,250,10,7,0,0,250,251,5,5,0,0,251,271,3,34,17,8,252,253,
        10,6,0,0,253,254,5,3,0,0,254,271,3,34,17,7,255,256,10,5,0,0,256,
        257,5,10,0,0,257,271,3,34,17,6,258,259,10,4,0,0,259,260,5,11,0,0,
        260,271,3,34,17,5,261,262,10,3,0,0,262,263,5,6,0,0,263,271,3,34,
        17,4,264,265,10,2,0,0,265,266,5,9,0,0,266,271,3,34,17,3,267,268,
        10,1,0,0,268,269,5,7,0,0,269,271,3,34,17,2,270,243,1,0,0,0,270,246,
        1,0,0,0,270,249,1,0,0,0,270,252,1,0,0,0,270,255,1,0,0,0,270,258,
        1,0,0,0,270,261,1,0,0,0,270,264,1,0,0,0,270,267,1,0,0,0,271,274,
        1,0,0,0,272,270,1,0,0,0,272,273,1,0,0,0,273,35,1,0,0,0,274,272,1,
        0,0,0,18,39,65,85,96,105,127,137,142,153,167,179,195,198,205,219,
        241,270,272
    ]

class grammaParser ( Parser ):

    grammarFileName = "gramma.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "'+'", "'-'", "'*'", "'/'", "'<'", 
                     "'>'", "'!='", "'=='", "'+='", "'-='", "'('", "')'", 
                     "'{'", "'}'", "'['", "']'", "':'", "','", "';'", "'.'", 
                     "'if'", "'while'", "'case'", "'switch'", "'sub_prog'", 
                     "'return'", "'for'", "'else'", "'write'", "'read'", 
                     "'break'", "'true'", "'false'", "'prog'", "'\\n'" ]

    symbolicNames = [ "<INVALID>", "EQ", "PLUS", "DIFFER", "MULTI", "QUONTIENT", 
                      "LESS", "MORRE", "NEQ", "COMPR", "INCR", "DECR", "LBRACKET", 
                      "RBRACKET", "LCURLBR", "RCURLBR", "LSQBR", "RSQBR", 
                      "COLON", "COMMA", "DCOMA", "DOT", "IF", "WHILE", "CASE", 
                      "SWITCH", "SUBPROG", "RETURN", "FOR", "ELSE", "WRITE", 
                      "READ", "BREAK", "TRUE", "FALSE", "PROG", "NEWLINE", 
                      "FLOAT", "INT", "STR", "CHAR", "ID", "WS" ]

    RULE_program = 0
    RULE_stat = 1
    RULE_in_crit = 2
    RULE_short_stat = 3
    RULE_long_stat = 4
    RULE_write_st = 5
    RULE_read_st = 6
    RULE_if_st = 7
    RULE_in_else = 8
    RULE_while_st = 9
    RULE_swich_st = 10
    RULE_case_st = 11
    RULE_sub_programm = 12
    RULE_sub_pr_get = 13
    RULE_return_st = 14
    RULE_dupl = 15
    RULE_spr_arg = 16
    RULE_expr = 17

    ruleNames =  [ "program", "stat", "in_crit", "short_stat", "long_stat", 
                   "write_st", "read_st", "if_st", "in_else", "while_st", 
                   "swich_st", "case_st", "sub_programm", "sub_pr_get", 
                   "return_st", "dupl", "spr_arg", "expr" ]

    EOF = Token.EOF
    EQ=1
    PLUS=2
    DIFFER=3
    MULTI=4
    QUONTIENT=5
    LESS=6
    MORRE=7
    NEQ=8
    COMPR=9
    INCR=10
    DECR=11
    LBRACKET=12
    RBRACKET=13
    LCURLBR=14
    RCURLBR=15
    LSQBR=16
    RSQBR=17
    COLON=18
    COMMA=19
    DCOMA=20
    DOT=21
    IF=22
    WHILE=23
    CASE=24
    SWITCH=25
    SUBPROG=26
    RETURN=27
    FOR=28
    ELSE=29
    WRITE=30
    READ=31
    BREAK=32
    TRUE=33
    FALSE=34
    PROG=35
    NEWLINE=36
    FLOAT=37
    INT=38
    STR=39
    CHAR=40
    ID=41
    WS=42

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.12.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(grammaParser.EOF, 0)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.StatContext)
            else:
                return self.getTypedRuleContext(grammaParser.StatContext,i)


        def getRuleIndex(self):
            return grammaParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = grammaParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 39
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==36:
                self.state = 36
                self.stat()
                self.state = 41
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 42
            self.match(grammaParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(grammaParser.NEWLINE, 0)

        def short_stat(self):
            return self.getTypedRuleContext(grammaParser.Short_statContext,0)


        def long_stat(self):
            return self.getTypedRuleContext(grammaParser.Long_statContext,0)


        def if_st(self):
            return self.getTypedRuleContext(grammaParser.If_stContext,0)


        def while_st(self):
            return self.getTypedRuleContext(grammaParser.While_stContext,0)


        def expr(self):
            return self.getTypedRuleContext(grammaParser.ExprContext,0)


        def write_st(self):
            return self.getTypedRuleContext(grammaParser.Write_stContext,0)


        def read_st(self):
            return self.getTypedRuleContext(grammaParser.Read_stContext,0)


        def swich_st(self):
            return self.getTypedRuleContext(grammaParser.Swich_stContext,0)


        def sub_programm(self):
            return self.getTypedRuleContext(grammaParser.Sub_programmContext,0)


        def sub_pr_get(self):
            return self.getTypedRuleContext(grammaParser.Sub_pr_getContext,0)


        def return_st(self):
            return self.getTypedRuleContext(grammaParser.Return_stContext,0)


        def getRuleIndex(self):
            return grammaParser.RULE_stat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStat" ):
                listener.enterStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStat" ):
                listener.exitStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStat" ):
                return visitor.visitStat(self)
            else:
                return visitor.visitChildren(self)




    def stat(self):

        localctx = grammaParser.StatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stat)
        try:
            self.state = 65
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 44
                self.match(grammaParser.NEWLINE)
                self.state = 45
                self.short_stat()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 46
                self.match(grammaParser.NEWLINE)
                self.state = 47
                self.long_stat()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 48
                self.match(grammaParser.NEWLINE)
                self.state = 49
                self.if_st()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 50
                self.match(grammaParser.NEWLINE)
                self.state = 51
                self.while_st()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 52
                self.match(grammaParser.NEWLINE)
                self.state = 53
                self.expr(0)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 54
                self.match(grammaParser.NEWLINE)
                self.state = 55
                self.write_st()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 56
                self.match(grammaParser.NEWLINE)
                self.state = 57
                self.read_st()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 58
                self.swich_st()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 59
                self.match(grammaParser.NEWLINE)
                self.state = 60
                self.sub_programm()
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 61
                self.match(grammaParser.NEWLINE)
                self.state = 62
                self.sub_pr_get()
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 63
                self.match(grammaParser.NEWLINE)
                self.state = 64
                self.return_st()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class In_critContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.ExprContext)
            else:
                return self.getTypedRuleContext(grammaParser.ExprContext,i)


        def LESS(self):
            return self.getToken(grammaParser.LESS, 0)

        def MORRE(self):
            return self.getToken(grammaParser.MORRE, 0)

        def COMPR(self):
            return self.getToken(grammaParser.COMPR, 0)

        def ID(self):
            return self.getToken(grammaParser.ID, 0)

        def TRUE(self):
            return self.getToken(grammaParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(grammaParser.FALSE, 0)

        def getRuleIndex(self):
            return grammaParser.RULE_in_crit

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIn_crit" ):
                listener.enterIn_crit(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIn_crit" ):
                listener.exitIn_crit(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIn_crit" ):
                return visitor.visitIn_crit(self)
            else:
                return visitor.visitChildren(self)




    def in_crit(self):

        localctx = grammaParser.In_critContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_in_crit)
        try:
            self.state = 85
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 67
                self.expr(0)
                self.state = 68
                self.match(grammaParser.LESS)
                self.state = 69
                self.expr(0)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 71
                self.expr(0)
                self.state = 72
                self.match(grammaParser.MORRE)
                self.state = 73
                self.expr(0)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 75
                self.expr(0)
                self.state = 76
                self.match(grammaParser.COMPR)
                self.state = 77
                self.expr(0)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 79
                self.match(grammaParser.ID)
                self.state = 80
                self.match(grammaParser.COMPR)
                self.state = 81
                self.match(grammaParser.TRUE)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 82
                self.match(grammaParser.ID)
                self.state = 83
                self.match(grammaParser.COMPR)
                self.state = 84
                self.match(grammaParser.FALSE)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Short_statContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(grammaParser.ID, 0)

        def EQ(self):
            return self.getToken(grammaParser.EQ, 0)

        def expr(self):
            return self.getTypedRuleContext(grammaParser.ExprContext,0)


        def getRuleIndex(self):
            return grammaParser.RULE_short_stat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShort_stat" ):
                listener.enterShort_stat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShort_stat" ):
                listener.exitShort_stat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitShort_stat" ):
                return visitor.visitShort_stat(self)
            else:
                return visitor.visitChildren(self)




    def short_stat(self):

        localctx = grammaParser.Short_statContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_short_stat)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 87
            self.match(grammaParser.ID)
            self.state = 88
            self.match(grammaParser.EQ)
            self.state = 89
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Long_statContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(grammaParser.ID)
            else:
                return self.getToken(grammaParser.ID, i)

        def EQ(self):
            return self.getToken(grammaParser.EQ, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.ExprContext)
            else:
                return self.getTypedRuleContext(grammaParser.ExprContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(grammaParser.COMMA)
            else:
                return self.getToken(grammaParser.COMMA, i)

        def getRuleIndex(self):
            return grammaParser.RULE_long_stat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLong_stat" ):
                listener.enterLong_stat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLong_stat" ):
                listener.exitLong_stat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLong_stat" ):
                return visitor.visitLong_stat(self)
            else:
                return visitor.visitChildren(self)




    def long_stat(self):

        localctx = grammaParser.Long_statContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_long_stat)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 91
            self.match(grammaParser.ID)
            self.state = 96
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==19:
                self.state = 92
                self.match(grammaParser.COMMA)
                self.state = 93
                self.match(grammaParser.ID)
                self.state = 98
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 99
            self.match(grammaParser.EQ)
            self.state = 100
            self.expr(0)
            self.state = 105
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==19:
                self.state = 101
                self.match(grammaParser.COMMA)
                self.state = 102
                self.expr(0)
                self.state = 107
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Write_stContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WRITE(self):
            return self.getToken(grammaParser.WRITE, 0)

        def LBRACKET(self):
            return self.getToken(grammaParser.LBRACKET, 0)

        def ID(self):
            return self.getToken(grammaParser.ID, 0)

        def RBRACKET(self):
            return self.getToken(grammaParser.RBRACKET, 0)

        def getRuleIndex(self):
            return grammaParser.RULE_write_st

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWrite_st" ):
                listener.enterWrite_st(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWrite_st" ):
                listener.exitWrite_st(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWrite_st" ):
                return visitor.visitWrite_st(self)
            else:
                return visitor.visitChildren(self)




    def write_st(self):

        localctx = grammaParser.Write_stContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_write_st)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 108
            self.match(grammaParser.WRITE)
            self.state = 109
            self.match(grammaParser.LBRACKET)
            self.state = 110
            self.match(grammaParser.ID)
            self.state = 111
            self.match(grammaParser.RBRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Read_stContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(grammaParser.ID, 0)

        def EQ(self):
            return self.getToken(grammaParser.EQ, 0)

        def READ(self):
            return self.getToken(grammaParser.READ, 0)

        def LBRACKET(self):
            return self.getToken(grammaParser.LBRACKET, 0)

        def RBRACKET(self):
            return self.getToken(grammaParser.RBRACKET, 0)

        def getRuleIndex(self):
            return grammaParser.RULE_read_st

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRead_st" ):
                listener.enterRead_st(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRead_st" ):
                listener.exitRead_st(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRead_st" ):
                return visitor.visitRead_st(self)
            else:
                return visitor.visitChildren(self)




    def read_st(self):

        localctx = grammaParser.Read_stContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_read_st)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 113
            self.match(grammaParser.ID)
            self.state = 114
            self.match(grammaParser.EQ)
            self.state = 115
            self.match(grammaParser.READ)
            self.state = 116
            self.match(grammaParser.LBRACKET)
            self.state = 117
            self.match(grammaParser.RBRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class If_stContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(grammaParser.IF, 0)

        def LBRACKET(self):
            return self.getToken(grammaParser.LBRACKET, 0)

        def in_crit(self):
            return self.getTypedRuleContext(grammaParser.In_critContext,0)


        def RBRACKET(self):
            return self.getToken(grammaParser.RBRACKET, 0)

        def LCURLBR(self, i:int=None):
            if i is None:
                return self.getTokens(grammaParser.LCURLBR)
            else:
                return self.getToken(grammaParser.LCURLBR, i)

        def RCURLBR(self, i:int=None):
            if i is None:
                return self.getTokens(grammaParser.RCURLBR)
            else:
                return self.getToken(grammaParser.RCURLBR, i)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.StatContext)
            else:
                return self.getTypedRuleContext(grammaParser.StatContext,i)


        def NEWLINE(self):
            return self.getToken(grammaParser.NEWLINE, 0)

        def ELSE(self):
            return self.getToken(grammaParser.ELSE, 0)

        def in_else(self):
            return self.getTypedRuleContext(grammaParser.In_elseContext,0)


        def getRuleIndex(self):
            return grammaParser.RULE_if_st

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIf_st" ):
                listener.enterIf_st(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIf_st" ):
                listener.exitIf_st(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIf_st" ):
                return visitor.visitIf_st(self)
            else:
                return visitor.visitChildren(self)




    def if_st(self):

        localctx = grammaParser.If_stContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_if_st)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 119
            self.match(grammaParser.IF)
            self.state = 120
            self.match(grammaParser.LBRACKET)
            self.state = 121
            self.in_crit()
            self.state = 122
            self.match(grammaParser.RBRACKET)
            self.state = 123
            self.match(grammaParser.LCURLBR)
            self.state = 127
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==36:
                self.state = 124
                self.stat()
                self.state = 129
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 130
            self.match(grammaParser.RCURLBR)
            self.state = 137
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.state = 131
                self.match(grammaParser.NEWLINE)
                self.state = 132
                self.match(grammaParser.ELSE)
                self.state = 133
                self.match(grammaParser.LCURLBR)
                self.state = 134
                self.in_else()
                self.state = 135
                self.match(grammaParser.RCURLBR)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class In_elseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.StatContext)
            else:
                return self.getTypedRuleContext(grammaParser.StatContext,i)


        def getRuleIndex(self):
            return grammaParser.RULE_in_else

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIn_else" ):
                listener.enterIn_else(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIn_else" ):
                listener.exitIn_else(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIn_else" ):
                return visitor.visitIn_else(self)
            else:
                return visitor.visitChildren(self)




    def in_else(self):

        localctx = grammaParser.In_elseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_in_else)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 142
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==36:
                self.state = 139
                self.stat()
                self.state = 144
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class While_stContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(grammaParser.WHILE, 0)

        def LBRACKET(self):
            return self.getToken(grammaParser.LBRACKET, 0)

        def in_crit(self):
            return self.getTypedRuleContext(grammaParser.In_critContext,0)


        def RBRACKET(self):
            return self.getToken(grammaParser.RBRACKET, 0)

        def LCURLBR(self):
            return self.getToken(grammaParser.LCURLBR, 0)

        def RCURLBR(self):
            return self.getToken(grammaParser.RCURLBR, 0)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.StatContext)
            else:
                return self.getTypedRuleContext(grammaParser.StatContext,i)


        def getRuleIndex(self):
            return grammaParser.RULE_while_st

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhile_st" ):
                listener.enterWhile_st(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhile_st" ):
                listener.exitWhile_st(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhile_st" ):
                return visitor.visitWhile_st(self)
            else:
                return visitor.visitChildren(self)




    def while_st(self):

        localctx = grammaParser.While_stContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_while_st)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 145
            self.match(grammaParser.WHILE)
            self.state = 146
            self.match(grammaParser.LBRACKET)
            self.state = 147
            self.in_crit()
            self.state = 148
            self.match(grammaParser.RBRACKET)
            self.state = 149
            self.match(grammaParser.LCURLBR)
            self.state = 153
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==36:
                self.state = 150
                self.stat()
                self.state = 155
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 156
            self.match(grammaParser.RCURLBR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Swich_stContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(grammaParser.NEWLINE, 0)

        def SWITCH(self):
            return self.getToken(grammaParser.SWITCH, 0)

        def LBRACKET(self):
            return self.getToken(grammaParser.LBRACKET, 0)

        def ID(self):
            return self.getToken(grammaParser.ID, 0)

        def RBRACKET(self):
            return self.getToken(grammaParser.RBRACKET, 0)

        def LCURLBR(self):
            return self.getToken(grammaParser.LCURLBR, 0)

        def RCURLBR(self):
            return self.getToken(grammaParser.RCURLBR, 0)

        def case_st(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.Case_stContext)
            else:
                return self.getTypedRuleContext(grammaParser.Case_stContext,i)


        def getRuleIndex(self):
            return grammaParser.RULE_swich_st

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSwich_st" ):
                listener.enterSwich_st(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSwich_st" ):
                listener.exitSwich_st(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSwich_st" ):
                return visitor.visitSwich_st(self)
            else:
                return visitor.visitChildren(self)




    def swich_st(self):

        localctx = grammaParser.Swich_stContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_swich_st)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.match(grammaParser.NEWLINE)
            self.state = 159
            self.match(grammaParser.SWITCH)
            self.state = 160
            self.match(grammaParser.LBRACKET)
            self.state = 161
            self.match(grammaParser.ID)
            self.state = 162
            self.match(grammaParser.RBRACKET)
            self.state = 163
            self.match(grammaParser.LCURLBR)
            self.state = 167
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==36:
                self.state = 164
                self.case_st()
                self.state = 169
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 170
            self.match(grammaParser.RCURLBR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Case_stContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(grammaParser.NEWLINE)
            else:
                return self.getToken(grammaParser.NEWLINE, i)

        def CASE(self):
            return self.getToken(grammaParser.CASE, 0)

        def INT(self):
            return self.getToken(grammaParser.INT, 0)

        def LCURLBR(self):
            return self.getToken(grammaParser.LCURLBR, 0)

        def BREAK(self):
            return self.getToken(grammaParser.BREAK, 0)

        def RCURLBR(self):
            return self.getToken(grammaParser.RCURLBR, 0)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.StatContext)
            else:
                return self.getTypedRuleContext(grammaParser.StatContext,i)


        def getRuleIndex(self):
            return grammaParser.RULE_case_st

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCase_st" ):
                listener.enterCase_st(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCase_st" ):
                listener.exitCase_st(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCase_st" ):
                return visitor.visitCase_st(self)
            else:
                return visitor.visitChildren(self)




    def case_st(self):

        localctx = grammaParser.Case_stContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_case_st)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 172
            self.match(grammaParser.NEWLINE)
            self.state = 173
            self.match(grammaParser.CASE)
            self.state = 174
            self.match(grammaParser.INT)
            self.state = 175
            self.match(grammaParser.LCURLBR)
            self.state = 179
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,10,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 176
                    self.stat() 
                self.state = 181
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

            self.state = 182
            self.match(grammaParser.NEWLINE)
            self.state = 183
            self.match(grammaParser.BREAK)
            self.state = 184
            self.match(grammaParser.RCURLBR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Sub_programmContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SUBPROG(self):
            return self.getToken(grammaParser.SUBPROG, 0)

        def ID(self):
            return self.getToken(grammaParser.ID, 0)

        def LBRACKET(self):
            return self.getToken(grammaParser.LBRACKET, 0)

        def RBRACKET(self):
            return self.getToken(grammaParser.RBRACKET, 0)

        def LCURLBR(self):
            return self.getToken(grammaParser.LCURLBR, 0)

        def RCURLBR(self):
            return self.getToken(grammaParser.RCURLBR, 0)

        def WS(self):
            return self.getToken(grammaParser.WS, 0)

        def spr_arg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.Spr_argContext)
            else:
                return self.getTypedRuleContext(grammaParser.Spr_argContext,i)


        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.StatContext)
            else:
                return self.getTypedRuleContext(grammaParser.StatContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(grammaParser.COMMA)
            else:
                return self.getToken(grammaParser.COMMA, i)

        def getRuleIndex(self):
            return grammaParser.RULE_sub_programm

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSub_programm" ):
                listener.enterSub_programm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSub_programm" ):
                listener.exitSub_programm(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSub_programm" ):
                return visitor.visitSub_programm(self)
            else:
                return visitor.visitChildren(self)




    def sub_programm(self):

        localctx = grammaParser.Sub_programmContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_sub_programm)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 186
            self.match(grammaParser.SUBPROG)
            self.state = 187
            self.match(grammaParser.ID)
            self.state = 188
            self.match(grammaParser.LBRACKET)
            self.state = 198
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [42]:
                self.state = 189
                self.match(grammaParser.WS)
                pass
            elif token in [38, 39, 40, 41]:
                self.state = 190
                self.spr_arg()
                self.state = 195
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==19:
                    self.state = 191
                    self.match(grammaParser.COMMA)
                    self.state = 192
                    self.spr_arg()
                    self.state = 197
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            else:
                raise NoViableAltException(self)

            self.state = 200
            self.match(grammaParser.RBRACKET)
            self.state = 201
            self.match(grammaParser.LCURLBR)
            self.state = 205
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==36:
                self.state = 202
                self.stat()
                self.state = 207
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 208
            self.match(grammaParser.RCURLBR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Sub_pr_getContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(grammaParser.ID)
            else:
                return self.getToken(grammaParser.ID, i)

        def EQ(self):
            return self.getToken(grammaParser.EQ, 0)

        def LBRACKET(self):
            return self.getToken(grammaParser.LBRACKET, 0)

        def spr_arg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.Spr_argContext)
            else:
                return self.getTypedRuleContext(grammaParser.Spr_argContext,i)


        def RBRACKET(self):
            return self.getToken(grammaParser.RBRACKET, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(grammaParser.COMMA)
            else:
                return self.getToken(grammaParser.COMMA, i)

        def getRuleIndex(self):
            return grammaParser.RULE_sub_pr_get

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSub_pr_get" ):
                listener.enterSub_pr_get(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSub_pr_get" ):
                listener.exitSub_pr_get(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSub_pr_get" ):
                return visitor.visitSub_pr_get(self)
            else:
                return visitor.visitChildren(self)




    def sub_pr_get(self):

        localctx = grammaParser.Sub_pr_getContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_sub_pr_get)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 210
            self.match(grammaParser.ID)
            self.state = 211
            self.match(grammaParser.EQ)
            self.state = 212
            self.match(grammaParser.ID)
            self.state = 213
            self.match(grammaParser.LBRACKET)
            self.state = 214
            self.spr_arg()
            self.state = 219
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==19:
                self.state = 215
                self.match(grammaParser.COMMA)
                self.state = 216
                self.spr_arg()
                self.state = 221
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 222
            self.match(grammaParser.RBRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Return_stContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(grammaParser.RETURN, 0)

        def expr(self):
            return self.getTypedRuleContext(grammaParser.ExprContext,0)


        def getRuleIndex(self):
            return grammaParser.RULE_return_st

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReturn_st" ):
                listener.enterReturn_st(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReturn_st" ):
                listener.exitReturn_st(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReturn_st" ):
                return visitor.visitReturn_st(self)
            else:
                return visitor.visitChildren(self)




    def return_st(self):

        localctx = grammaParser.Return_stContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_return_st)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 224
            self.match(grammaParser.RETURN)
            self.state = 225
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DuplContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LSQBR(self):
            return self.getToken(grammaParser.LSQBR, 0)

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(grammaParser.INT)
            else:
                return self.getToken(grammaParser.INT, i)

        def COMMA(self):
            return self.getToken(grammaParser.COMMA, 0)

        def RSQBR(self):
            return self.getToken(grammaParser.RSQBR, 0)

        def getRuleIndex(self):
            return grammaParser.RULE_dupl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDupl" ):
                listener.enterDupl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDupl" ):
                listener.exitDupl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDupl" ):
                return visitor.visitDupl(self)
            else:
                return visitor.visitChildren(self)




    def dupl(self):

        localctx = grammaParser.DuplContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_dupl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 227
            self.match(grammaParser.LSQBR)
            self.state = 228
            self.match(grammaParser.INT)
            self.state = 229
            self.match(grammaParser.COMMA)
            self.state = 230
            self.match(grammaParser.INT)
            self.state = 231
            self.match(grammaParser.RSQBR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Spr_argContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(grammaParser.ID, 0)

        def INT(self):
            return self.getToken(grammaParser.INT, 0)

        def CHAR(self):
            return self.getToken(grammaParser.CHAR, 0)

        def STR(self):
            return self.getToken(grammaParser.STR, 0)

        def getRuleIndex(self):
            return grammaParser.RULE_spr_arg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSpr_arg" ):
                listener.enterSpr_arg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSpr_arg" ):
                listener.exitSpr_arg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSpr_arg" ):
                return visitor.visitSpr_arg(self)
            else:
                return visitor.visitChildren(self)




    def spr_arg(self):

        localctx = grammaParser.Spr_argContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_spr_arg)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 233
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 4123168604160) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(grammaParser.ID, 0)

        def INT(self):
            return self.getToken(grammaParser.INT, 0)

        def CHAR(self):
            return self.getToken(grammaParser.CHAR, 0)

        def STR(self):
            return self.getToken(grammaParser.STR, 0)

        def dupl(self):
            return self.getTypedRuleContext(grammaParser.DuplContext,0)


        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(grammaParser.ExprContext)
            else:
                return self.getTypedRuleContext(grammaParser.ExprContext,i)


        def PLUS(self):
            return self.getToken(grammaParser.PLUS, 0)

        def MULTI(self):
            return self.getToken(grammaParser.MULTI, 0)

        def QUONTIENT(self):
            return self.getToken(grammaParser.QUONTIENT, 0)

        def DIFFER(self):
            return self.getToken(grammaParser.DIFFER, 0)

        def INCR(self):
            return self.getToken(grammaParser.INCR, 0)

        def DECR(self):
            return self.getToken(grammaParser.DECR, 0)

        def LESS(self):
            return self.getToken(grammaParser.LESS, 0)

        def COMPR(self):
            return self.getToken(grammaParser.COMPR, 0)

        def MORRE(self):
            return self.getToken(grammaParser.MORRE, 0)

        def getRuleIndex(self):
            return grammaParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr" ):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = grammaParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 34
        self.enterRecursionRule(localctx, 34, self.RULE_expr, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 241
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [41]:
                self.state = 236
                self.match(grammaParser.ID)
                pass
            elif token in [38]:
                self.state = 237
                self.match(grammaParser.INT)
                pass
            elif token in [40]:
                self.state = 238
                self.match(grammaParser.CHAR)
                pass
            elif token in [39]:
                self.state = 239
                self.match(grammaParser.STR)
                pass
            elif token in [16]:
                self.state = 240
                self.dupl()
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 272
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,17,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 270
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
                    if la_ == 1:
                        localctx = grammaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 243
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 244
                        self.match(grammaParser.PLUS)
                        self.state = 245
                        self.expr(10)
                        pass

                    elif la_ == 2:
                        localctx = grammaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 246
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 247
                        self.match(grammaParser.MULTI)
                        self.state = 248
                        self.expr(9)
                        pass

                    elif la_ == 3:
                        localctx = grammaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 249
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 250
                        self.match(grammaParser.QUONTIENT)
                        self.state = 251
                        self.expr(8)
                        pass

                    elif la_ == 4:
                        localctx = grammaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 252
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 253
                        self.match(grammaParser.DIFFER)
                        self.state = 254
                        self.expr(7)
                        pass

                    elif la_ == 5:
                        localctx = grammaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 255
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 256
                        self.match(grammaParser.INCR)
                        self.state = 257
                        self.expr(6)
                        pass

                    elif la_ == 6:
                        localctx = grammaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 258
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 259
                        self.match(grammaParser.DECR)
                        self.state = 260
                        self.expr(5)
                        pass

                    elif la_ == 7:
                        localctx = grammaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 261
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 262
                        self.match(grammaParser.LESS)
                        self.state = 263
                        self.expr(4)
                        pass

                    elif la_ == 8:
                        localctx = grammaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 264
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 265
                        self.match(grammaParser.COMPR)
                        self.state = 266
                        self.expr(3)
                        pass

                    elif la_ == 9:
                        localctx = grammaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 267
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 268
                        self.match(grammaParser.MORRE)
                        self.state = 269
                        self.expr(2)
                        pass

             
                self.state = 274
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,17,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[17] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 2)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 1)
         




