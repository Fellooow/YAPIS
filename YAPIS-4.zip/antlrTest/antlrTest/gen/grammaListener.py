# Generated from C:/Users/Asus/PycharmProjects/antlrTest\gramma.g4 by ANTLR 4.12.0
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .grammaParser import grammaParser
else:
    from grammaParser import grammaParser

# This class defines a complete listener for a parse tree produced by grammaParser.
class grammaListener(ParseTreeListener):

    # Enter a parse tree produced by grammaParser#program.
    def enterProgram(self, ctx:grammaParser.ProgramContext):
        pass

    # Exit a parse tree produced by grammaParser#program.
    def exitProgram(self, ctx:grammaParser.ProgramContext):
        pass


    # Enter a parse tree produced by grammaParser#stat.
    def enterStat(self, ctx:grammaParser.StatContext):
        pass

    # Exit a parse tree produced by grammaParser#stat.
    def exitStat(self, ctx:grammaParser.StatContext):
        pass


    # Enter a parse tree produced by grammaParser#in_crit.
    def enterIn_crit(self, ctx:grammaParser.In_critContext):
        pass

    # Exit a parse tree produced by grammaParser#in_crit.
    def exitIn_crit(self, ctx:grammaParser.In_critContext):
        pass


    # Enter a parse tree produced by grammaParser#short_stat.
    def enterShort_stat(self, ctx:grammaParser.Short_statContext):
        pass

    # Exit a parse tree produced by grammaParser#short_stat.
    def exitShort_stat(self, ctx:grammaParser.Short_statContext):
        pass


    # Enter a parse tree produced by grammaParser#long_stat.
    def enterLong_stat(self, ctx:grammaParser.Long_statContext):
        pass

    # Exit a parse tree produced by grammaParser#long_stat.
    def exitLong_stat(self, ctx:grammaParser.Long_statContext):
        pass


    # Enter a parse tree produced by grammaParser#write_st.
    def enterWrite_st(self, ctx:grammaParser.Write_stContext):
        pass

    # Exit a parse tree produced by grammaParser#write_st.
    def exitWrite_st(self, ctx:grammaParser.Write_stContext):
        pass


    # Enter a parse tree produced by grammaParser#read_st.
    def enterRead_st(self, ctx:grammaParser.Read_stContext):
        pass

    # Exit a parse tree produced by grammaParser#read_st.
    def exitRead_st(self, ctx:grammaParser.Read_stContext):
        pass


    # Enter a parse tree produced by grammaParser#if_st.
    def enterIf_st(self, ctx:grammaParser.If_stContext):
        pass

    # Exit a parse tree produced by grammaParser#if_st.
    def exitIf_st(self, ctx:grammaParser.If_stContext):
        pass


    # Enter a parse tree produced by grammaParser#in_else.
    def enterIn_else(self, ctx:grammaParser.In_elseContext):
        pass

    # Exit a parse tree produced by grammaParser#in_else.
    def exitIn_else(self, ctx:grammaParser.In_elseContext):
        pass


    # Enter a parse tree produced by grammaParser#while_st.
    def enterWhile_st(self, ctx:grammaParser.While_stContext):
        pass

    # Exit a parse tree produced by grammaParser#while_st.
    def exitWhile_st(self, ctx:grammaParser.While_stContext):
        pass


    # Enter a parse tree produced by grammaParser#swich_st.
    def enterSwich_st(self, ctx:grammaParser.Swich_stContext):
        pass

    # Exit a parse tree produced by grammaParser#swich_st.
    def exitSwich_st(self, ctx:grammaParser.Swich_stContext):
        pass


    # Enter a parse tree produced by grammaParser#case_st.
    def enterCase_st(self, ctx:grammaParser.Case_stContext):
        pass

    # Exit a parse tree produced by grammaParser#case_st.
    def exitCase_st(self, ctx:grammaParser.Case_stContext):
        pass


    # Enter a parse tree produced by grammaParser#sub_programm.
    def enterSub_programm(self, ctx:grammaParser.Sub_programmContext):
        pass

    # Exit a parse tree produced by grammaParser#sub_programm.
    def exitSub_programm(self, ctx:grammaParser.Sub_programmContext):
        pass


    # Enter a parse tree produced by grammaParser#sub_pr_get.
    def enterSub_pr_get(self, ctx:grammaParser.Sub_pr_getContext):
        pass

    # Exit a parse tree produced by grammaParser#sub_pr_get.
    def exitSub_pr_get(self, ctx:grammaParser.Sub_pr_getContext):
        pass


    # Enter a parse tree produced by grammaParser#return_st.
    def enterReturn_st(self, ctx:grammaParser.Return_stContext):
        pass

    # Exit a parse tree produced by grammaParser#return_st.
    def exitReturn_st(self, ctx:grammaParser.Return_stContext):
        pass


    # Enter a parse tree produced by grammaParser#dupl.
    def enterDupl(self, ctx:grammaParser.DuplContext):
        pass

    # Exit a parse tree produced by grammaParser#dupl.
    def exitDupl(self, ctx:grammaParser.DuplContext):
        pass


    # Enter a parse tree produced by grammaParser#spr_arg.
    def enterSpr_arg(self, ctx:grammaParser.Spr_argContext):
        pass

    # Exit a parse tree produced by grammaParser#spr_arg.
    def exitSpr_arg(self, ctx:grammaParser.Spr_argContext):
        pass


    # Enter a parse tree produced by grammaParser#expr.
    def enterExpr(self, ctx:grammaParser.ExprContext):
        pass

    # Exit a parse tree produced by grammaParser#expr.
    def exitExpr(self, ctx:grammaParser.ExprContext):
        pass



del grammaParser